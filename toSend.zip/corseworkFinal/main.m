function [ output ] = main(sequence1 ,sequence2,gapPenelty )
    %basic gobal alginment
    [scoreNormal,alignmentNormal,scoreTable] = basicalginSequence( sequence1 ,sequence2,gapPenelty );
    scoreNormal=scoreNormal
    alignmentNormal=alignmentNormal
    scoreTable=scoreTable
    %basic gobal alginment where not beign in the middle of sequence means no gap penelty 
    [scoreNormal,alignmentNormal,scoreTable] = alginSequence( sequence1 ,sequence2,gapPenelty );
    scoreNormal=scoreNormal
    alignmentNormal=alignmentNormal
    scoreTable=scoreTable
    %basic local alginment
    [ scoreLocal,alignmentLocal,scoreTable] = alginSequenceLocal( sequence1 ,sequence2,gapPenelty );
    scoreLocal=scoreLocal
    alignmentLocal=alignmentLocal
    scoreTable=scoreTable
    %gobal alginment where the gap grows if gaps chain
    [ scoreLinearGrowingGapPenelty,alignmentLinearGrowingGapPenelty,scoreTable,gapTable]=alginSequenceGrowingGapLinear(sequence1,sequence2,gapPenelty);
    scoreLinearGrowingGapPenelty=scoreLinearGrowingGapPenelty
    alignmentLinearGrowingGapPenelty=alignmentLinearGrowingGapPenelty
    scoreTable=scoreTable
    gapTable=gapTable
 
    %gobal alginment where a gap has a opening gap penelty 
    [ scoreOpeningGapPenelty,alignmentOpeningGapPenelty,scoreTable,gapTable]=alginSequenceGrowingGapOpening(sequence1,sequence2,gapPenelty);
    scoreOpeningGapPenelty=scoreOpeningGapPenelty
    alignmentOpeningGapPenelty=alignmentOpeningGapPenelty
    scoreTable=scoreTable
    gapTable=gapTable

    
    output=12;
end

